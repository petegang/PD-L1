import pandas as pd
from rdkit import Chem
from rdkit.Chem import MACCSkeys
from mordred import Calculator, descriptors
from tqdm import tqdm  # 导入 tqdm 用于显示进度条
from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import Manager

# 创建 Mordred 描述符计算器
calc = Calculator(descriptors, ignore_3D=True)  # 默认计算1D和2D描述符

# 定义需要的 Mordred 描述符（注意：没有IC2）
required_descriptors = [
    'IC2', 'nAcid', 'SlogP_VSA8', 'FilterItLogS', 'PEOE_VSA2', 'NdssC',
    'MIC1', 'BCUTd-1h', 'NsOH', 'SdssC', 'SLogP', 'ZMIC1', 'VSA_EState2'
]

# 计算 MACCS 指纹活跃位点数（bit count）
def calculate_maccs_active_bits(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        maccs_fp = MACCSkeys.GenMACCSKeys(mol)
        return maccs_fp.GetNumOnBits()  # 活跃位点个数
    else:
        return None

# 计算所有描述符的函数
def calculate_descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        # Mordred 描述符
        desc = calc(mol)
        descriptor_values = {}
        for desc_name in required_descriptors:
            try:
                descriptor_values[desc_name] = desc[desc_name]
            except KeyError:
                descriptor_values[desc_name] = None

        # MACCS 活跃位点数
        descriptor_values['MACCS_ActiveBitsCount'] = calculate_maccs_active_bits(smiles)
        return descriptor_values
    else:
        return {desc: None for desc in required_descriptors + ['MACCS_ActiveBitsCount']}

# 子进程处理函数
def process_smiles(smiles, progress_queue):
    result = calculate_descriptors(smiles)
    progress_queue.put(1)
    return result

# 主函数
if __name__ == '__main__':
    # 读取数据
    df = pd.read_csv('2044-14.csv')  # 替换为你的文件路径

    manager = Manager()
    progress_queue = manager.Queue()

    # 显示进度条
    with tqdm(total=len(df), desc="Calculating Descriptors") as pbar:
        descriptors_list = []

        # 多进程处理
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(process_smiles, smiles, progress_queue) for smiles in df['SMILES']]
            for future in as_completed(futures):
                descriptors_list.append(future.result())
                progress_queue.get()
                pbar.update(1)

    # 构建新 DataFrame 并合并
    descriptors_df = pd.DataFrame(descriptors_list)
    df_with_descriptors = pd.concat([df, descriptors_df], axis=1)

    # 保存结果
    df_with_descriptors.to_csv('2044-14-descriptors.csv', index=False)
    print(df_with_descriptors.head())
